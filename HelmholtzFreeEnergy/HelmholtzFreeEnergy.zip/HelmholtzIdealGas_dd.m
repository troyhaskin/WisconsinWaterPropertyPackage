function HelmDeriv = HelmholtzIdealGas_dd(delta,~)
    HelmDeriv = -delta.^(-2);
end