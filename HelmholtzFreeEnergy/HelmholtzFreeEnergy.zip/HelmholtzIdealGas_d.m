function HelmDeriv = HelmholtzIdealGas_d(delta,~)
    HelmDeriv = delta.^(-1);
end
