function HelmDeriv = HelmholtzIdealGas_dt(~,~)
    HelmDeriv = 0.0;
end